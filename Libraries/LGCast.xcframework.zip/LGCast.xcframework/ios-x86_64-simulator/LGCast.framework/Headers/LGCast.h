//
//  LGCast.h
//  LGCast
//
//  Created by DeviceSynergyTask on 2021/04/21.
//

#import <Foundation/Foundation.h>

#import <GStreamerForLGCast/LCStreamer.h>
#import <GStreamerForLGCast/LCStreamerData.h>

//! Project version number for LGCast.
FOUNDATION_EXPORT double LGCastSDKVersionNumber;

//! Project version string for LGCast.
FOUNDATION_EXPORT const unsigned char LGCastSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LGCast/PublicHeader.h>
